# Security Policy

If you discover any security related issues, please email younes.khoubza@gmail.com instead of using the issue tracker.
